
<nav>

    <h2 class="text-green">Stonks Pizza</h2>
    <ul>
        <li><a href="{{ url('/') }}">Home</a></li>
        <li><a href="{{ url('/Winkelmandje') }}">Winkelwagen</a></li>
        <li><a href="{{ url('/order') }}">Bestelling</a></li>
        <li><a style="color: green;" class="text-red" href="{{ url('/register') }}">Login</a></li>
    </ul>
    </nav>
