@extends('layouts.app-layout')
@include('components.header')

@section('content')
@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<img src="Photos\1 (1).png" class="Images" id="Spin">
<p id="centeralignb" class="font-bold">We deliver your order to your doorstep!</p><br><br>

<div class="inspringen">
    <div class="checkmark" style="float: left;"></div>
    <p class="inspringen1 text-lg">The average delivery time is only 20 minutes.</p><br>
    <div class="checkmark" style="float: left;"></div>
    <p class="inspringen1 text-lg">Completely free delivery.</p><br>
    <div class="checkmark" style="float: left;"></div>
    <p class="inspringen1 text-lg">Specialized delivery personnel.</p><br>
    <div class="checkmark" style="float: left;"></div>
    <p class="inspringen1 text-lg">Transported under heat lamps.</p><br>
</div>

<div class="Area2">
    <div class="Area2_bg"></div>
    <p id="down" class="font-bold">Fresh from our oven!</p><br>

    <div class="inspringen2">
        <div class="checkmark" style="float: left;"></div>
        <p class="inspringen1 text-lg">All pizzas are fresh!</p><br>
        <div class="checkmark" style="float: left;"></div>
        <p class="inspringen1 text-lg">Vegetables are stored refrigerated.</p><br>
        <div class="checkmark" style="float: left;"></div>
        <p class="inspringen1 text-lg">Crispy pizza crust is guaranteed.</p><br>
        <div class="checkmark" style="float: left;"></div>
        <p class="inspringen1 text-lg">We make fresh dough every day.</p><br>
    </div>
    <img src="Photos\2.png" class="animate-bounce" id="Spin1">
</div>

@endsection
