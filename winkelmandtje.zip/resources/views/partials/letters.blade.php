<link rel="stylesheet" type="text/css" href="{{asset('letters/letter.css')}}">
<link rel="stylesheet" type="text/css" href="{{asset('css/app.css')}}">

<p>I'm a</p>
<b>
  <span1>
    web developer<br />
    css cowboy<br />
    self-facilitating media node<br />
    box inside a box<br />
    part of the problem
    </span1>
</b>



<script src="{{ asset('js/app.js') }}"></script>
