@extends('layouts.app-layout')
@include('components.header')

@section('content')
@if ($errors->any())
    <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    </div>
@endif

<div class="container px-6 mx-auto pt-[100px]">
    <div class="grid grid-cols-1 gap-6 mt-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        @foreach ($menus as $menu)
        <div class="w-full max-w-sm mx-auto overflow-hidden rounded-md shadow-md bg-white">
            <div class="flex items-end justify-end w-full bg-cover">
                <!-- Background image or any other visual element -->
            </div>
            <div class="px-5 py-3">
                <h1>{{ $menu->pizza }}</h1>
                <span class="mt-2 text-gray-500">€{{ $menu->prijs }}</span>
                <form action="{{ route('Cart.store') }}" method="POST">
                    @csrf
                    <input type="hidden" name="menu_id" value="{{ $menu->id }}">
                    <p>{{$menu->ingrediënten}}</p>
                    <img src="{{$menu->plaatje}}">

                    <input type="number" name="quantity" value="1" min="1">


    <select name="grootte" id="grootte">
        <option value="0.8">Klein 20cm</option>
        <option value="1" selected>Medium 25cm</option>
        <option value="1.2">Groot 30cm</option>
    </select>
                    <br>

                    <label for="ingredient">Ingredient Combination:</label>
                    <select name="ingredient" id="ingredient">
                        <option value="option1"> </option>
                        <option value="option2">ananas</option>
                        <option value="option3">jalepeno</option>
                        <option value="option4">ananas</option>
                        <option value="option5">takis</option>
                        <option value="option6">frietjes</option>
                        <option value="option7">jalepeno</option>
                    </select>

                    <br>

                    <label for="quantity">Quantity:</label>
                    <input type="number" name="quantity" id="quantity" value="1" min="1">
                    <input type="hidden" name="id" value="{{ $menu->id }}">

                    <br>

                    <button type="submit" class="px-4 py-2 text-white bg-blue-800 rounded">Toevoegen</button>
                </form>
                </form>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection
