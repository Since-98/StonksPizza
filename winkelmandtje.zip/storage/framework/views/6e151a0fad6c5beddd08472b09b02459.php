
<main style="margin-top: 2vw;">
    <img id="refresh-button" src="<?php echo e(asset('images/10.png')); ?>" onClick="window.location.reload();"/>
    <p id="order-status-label">Bestelstatus:</p>
    <div class="order-status">
        <?php if($order->status->id == 1): ?>
            <img src="<?php echo e(asset('images/4.png')); ?>"/>
            <p>Besteld</p>
        <?php elseif($order->status->id == 2): ?>
            <img src="<?php echo e(asset('images/8.png')); ?>"/>
            <p>Wordt bereid</p>
        <?php elseif($order->status->id == 3): ?>
            <img src="<?php echo e(asset('images/7.png')); ?>"/>
            <p>In oven</p>
        <?php elseif($order->status->id == 4): ?>
            <img src="<?php echo e(asset('images/1.png')); ?>"/>
            <p>Onderweg</p>
        <?php elseif($order->status->id == 5): ?>
            <img src="<?php echo e(asset('images/9.png')); ?>"/>
            <p>Bezorgd</p>
        <?php elseif($order->status->id == 6): ?>
            <img src="<?php echo e(asset('images/11.png')); ?>"/>
            <p>Geannuleerd</p>
        <?php endif; ?>
    </div>
    <div class="order-items-container" >
        <?php if($order->orderitems != null): ?>
            <?php $__currentLoopData = $order->orderitems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderitem_id => $orderitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="order-item">
                    <img src="<?php echo e(asset('images/3.png')); ?>">
                    <div class="order-item-description">
                        <p>Pizza <?php echo e($orderitem->pizza->name); ?> - <?php echo e($orderitem->size->name); ?></p>
                        <?php $__currentLoopData = $orderitem->ingredients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingredient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <p><?php echo e($ingredient->name); ?></p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="order-item-price">
                        <p>€<?php echo e(number_format($orderitem->price(), 2, ",", ".")); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="order-pricetotal">
                <p>Totaalprijs: €<?php echo e(number_format($order->price(), 2, ",", ".")); ?></p>
                <?php if($order->status->id != 4 && $order->status->id != 5 && $order->status->id != 6): ?>
                <form method="POST" action="<?php echo e(route('order.update', $order->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <button type="submit"class="order-item-delete">Bestelling annuleren</button>
                </form>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Data\School\Project3\StonksPizza\resources\views/order/show.blade.php ENDPATH**/ ?>