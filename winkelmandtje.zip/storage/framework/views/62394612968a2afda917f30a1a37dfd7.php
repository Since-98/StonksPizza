<?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<div class="container px-6 mx-auto pt-[100px]">
    <div class="grid grid-cols-1 gap-6 mt-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="w-full max-w-sm mx-auto overflow-hidden rounded-md shadow-md bg-white">
            <div class="flex items-end justify-end w-full bg-cover">
                <!-- Background image or any other visual element -->
            </div>
            <div class="px-5 py-3">
                <h1><?php echo e($menu->pizza); ?></h1>
                <span class="mt-2 text-gray-500">€<?php echo e($menu->prijs); ?></span>
                <form action="<?php echo e(route('Cart.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="menu_id" value="<?php echo e($menu->id); ?>">
                    <p><?php echo e($menu->ingrediënten); ?></p>
                    <img src="<?php echo e($menu->plaatje); ?>">

                    <input type="number" name="quantity" value="1" min="1">


    <select name="grootte" id="grootte">
        <option value="0.8">Klein 20cm</option>
        <option value="1" selected>Medium 25cm</option>
        <option value="1.2">Groot 30cm</option>
    </select>
                    <br>

                    <label for="ingredient">Ingredient Combination:</label>
                    <select name="ingredient" id="ingredient">
                        <option value="option1"> </option>
                        <option value="option2">ananas</option>
                        <option value="option3">jalepeno</option>
                        <option value="option4">ananas</option>
                        <option value="option5">takis</option>
                        <option value="option6">frietjes</option>
                        <option value="option7">jalepeno</option>
                    </select>

                    <br>

                    <label for="quantity">Quantity:</label>
                    <input type="number" name="quantity" id="quantity" value="1" min="1">
                    <input type="hidden" name="id" value="<?php echo e($menu->id); ?>">

                    <br>

                    <button type="submit" class="px-4 py-2 text-white bg-blue-800 rounded">Toevoegen</button>
                </form>
                </form>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Data\School\Project3\StonksPizza\resources\views/Menu/index.blade.php ENDPATH**/ ?>