<!-- resources/views/pizzas/index.blade.php -->

  

<?php $__env->startSection('content'); ?>
    <h1>Pizza Menu</h1>

    <div class="pizzas">
        <?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="pizza">
                <h2><?php echo e($pizza->name); ?></h2>
                <p><?php echo e($pizza->description); ?></p>
                <img src="<?php echo e(asset($pizza->photo_path)); ?>" alt="<?php echo e($pizza->name); ?>">
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Data\School\Project3\StonksPizza\resources\views/index.blade.php ENDPATH**/ ?>