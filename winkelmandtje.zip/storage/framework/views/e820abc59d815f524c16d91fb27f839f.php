
<nav>

    <h2 class="text-green">Stonks Pizza</h2>
    <ul>
        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
        <li><a href="<?php echo e(url('/Winkelmandje')); ?>">Winkelwagen</a></li>
        <li><a href="<?php echo e(url('/order')); ?>">Bestelling</a></li>
        <li><a style="color: green;" class="text-red" href="<?php echo e(url('/register')); ?>">Login</a></li>
    </ul>
    </nav>
<?php /**PATH C:\Data\School\Project3\StonksPizza\resources\views/layouts/nav.blade.php ENDPATH**/ ?>