<?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<img src="Photos\1 (1).png" class="Images" id="Spin">
<p id="centeralignb" class="font-bold">We deliver your order to your doorstep!</p><br><br>

<div class="inspringen">
    <div class="checkmark" style="float: left;"></div>
    <p class="inspringen1 text-lg">The average delivery time is only 20 minutes.</p><br>
    <div class="checkmark" style="float: left;"></div>
    <p class="inspringen1 text-lg">Completely free delivery.</p><br>
    <div class="checkmark" style="float: left;"></div>
    <p class="inspringen1 text-lg">Specialized delivery personnel.</p><br>
    <div class="checkmark" style="float: left;"></div>
    <p class="inspringen1 text-lg">Transported under heat lamps.</p><br>
</div>

<div class="Area2">
    <div class="Area2_bg"></div>
    <p id="down" class="font-bold">Fresh from our oven!</p><br>

    <div class="inspringen2">
        <div class="checkmark" style="float: left;"></div>
        <p class="inspringen1 text-lg">All pizzas are fresh!</p><br>
        <div class="checkmark" style="float: left;"></div>
        <p class="inspringen1 text-lg">Vegetables are stored refrigerated.</p><br>
        <div class="checkmark" style="float: left;"></div>
        <p class="inspringen1 text-lg">Crispy pizza crust is guaranteed.</p><br>
        <div class="checkmark" style="float: left;"></div>
        <p class="inspringen1 text-lg">We make fresh dough every day.</p><br>
    </div>
    <img src="Photos\2.png" class="animate-bounce" id="Spin1">
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Data\School\Project3\StonksPizza\resources\views/home.blade.php ENDPATH**/ ?>