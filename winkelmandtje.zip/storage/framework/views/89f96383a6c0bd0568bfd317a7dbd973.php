<?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>
<main class="my-8">
    <div class="container px-6 mx-auto pt-[100px]">
        <div class="flex justify-center my-6">
            <div class="flex flex-col w-full p-8 text-gray-800 bg-white shadow-lg pin-r pin-y md:w-4/5 lg:w-4/5">
                <?php if($message = Session::get('success')): ?>
                <div class="p-4 mb-3 bg-green-400 rounded">
                    <p class="text-green-800"><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>
                <h3 class="text-3xl text-bold">Details bestelling</h3>
                <div class="flex-1">
                    <?php
                    $totaal = 0;
                    $totalQuantity = 0; // Initialize total quantity
                    ?>

                    <table class="w-full text-sm lg:text-base" cellspacing="0">
                        <thead>
                            <tr class="h-12 uppercase">
                                <th class="text-left">Name</th>
                                <th class="hidden text-right md:table-cell">Grootte</th>
                                <th class="hidden text-right md:table-cell">Prijs</th>
                                <th class="hidden text-right md:table-cell">Ingredient</th>
                                <th class="hidden text-right md:table-cell">Aantal</th>
                                <th class="hidden text-right md:table-cell">Verwijder</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <a href="#">
                                        <p class="mb-2 md:ml-4"><?php echo e($item->pizza); ?></p>
                                    </a>
                                </td>
                                <?php
                                $totaalItem = $item->prijs * $item->grootte;
                                $totaal += $totaalItem;
                                $totalQuantity += $item->quantity; // Accumulate quantity
                                ?>
                                <td class="hidden text-right md:table-cell">
                                    <span class="text-sm font-medium lg:text-base">
                                        <?php echo e($item->grootte); ?>

                                    </span>
                                </td>
                                <td class="hidden text-right md:table-cell">
                                    <span class="text-sm font-medium lg:text-base">
                                        €<?php echo e($item->prijs); ?>

                                    </span>
                                </td>
                                <td class="hidden text-right md:table-cell">
                                    <span class="text-sm font-medium lg:text-base">
                                        <?php echo e($item->ingrediënten); ?>

                                    </span>
                                </td>
                                <td class="hidden text-right md:table-cell">
                                    <span class="text-sm font-medium lg:text-base">
                                        <?php echo e($item->quantity); ?>

                                    </span>
                                </td>
                                <td class="hidden text-right md:table-cell">

                                    <form action="<?php echo e(route('cart.destroy', ['id' => $item->id])); ?>" method="POST">
                                        <?php echo method_field('delete'); ?>
                                        <?php echo csrf_field(); ?>
                                        <button class="px-4 py-2 text-white bg-red-600">x</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    Totaalprijs: €<?php echo e($totaal); ?> (<?php echo e($totalQuantity); ?> pizza's)
                    <p>
                        <?php echo csrf_field(); ?>
                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <input type="hidden" name="name" value="<?php echo e($item->name); ?>">
                        <input type="hidden" name="groote" value="<?php echo e($item->grootte); ?>">
                        <input type="hidden" name="totaalprijs" value="<?php echo e($totaal); ?>">
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <button class="px-10 py-2 text-white bg-gray-600 rounded">Bestellen</button>
                    </p>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Data\School\Project3\StonksPizza\resources\views/cart/index.blade.php ENDPATH**/ ?>