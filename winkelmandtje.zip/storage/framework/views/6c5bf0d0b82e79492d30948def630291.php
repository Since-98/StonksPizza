<?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->startSection('content'); ?>

<main class="my-8">
  <div class="container mx-auto pt-[70px]">
    <div class="flex justify-center my-6">
      <div class="w-full md:w-4/5 lg:w-4/5 bg-white rounded-lg shadow-lg p-8">
        <?php if($message = Session::get('success')): ?>
          <div class="p-4 mb-4 bg-green-400 rounded">
            <p class="text-green-800"><?php echo e($message); ?></p>
          </div>
        <?php endif; ?>
        <h3 class="text-3xl font-bold mb-6">Winkelmandtje</h3>
        <div class="flex-1">
          <?php
            $totaal = 0;
          ?>
          <table class="w-full text-sm lg:text-base mb-6">
            <thead>
              <tr class="h-12 uppercase">
                <th class="text-left">Name</th>
                <th class="hidden md:table-cell text-right">Grootte</th>
                <th class="hidden md:table-cell text-right">Prijs</th>
                <th class="hidden md:table-cell text-right">Verwijder</th>
              </tr>
            </thead>
            <tbody>

              <tr>
                <td>
                  <a href="#">
                    <p class="mb-2 md:ml-4"></p>
                  </a>
                </td>
                <td class="hidden md:table-cell text-right">
                  <span class="text-sm font-medium lg:text-base"></span>
                </td>
                <td class="hidden md:table-cell text-right">
                  <span class="text-sm font-medium lg:text-base">€</span>
                </td>
                <td class="hidden md:table-cell text-right">
                  <form action="" method="POST">
                    <?php echo method_field('delete'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="px-4 py-2 text-white bg-red-600 rounded-full">x</button>
                  </form>
                </td>
              </tr>
            </tbody>
          </table>
          <div class="mt-4">
            <p class="text-lg font-bold">Totaalprijs: €<?php echo e($totaal); ?></p> 
            <form action="" method="POST">
              <?php echo csrf_field(); ?>
              <input type="hidden" name="name" value="">
              <input type="hidden" name="groote" value="">
              <input type="hidden" name="totaalprijs" value="<?php echo e($totaal); ?>">
              <button type="submit" class="px-8 py-3 text-white bg-gray-600 rounded-full mt-4">Bestellen</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Data\School\Project3\StonksPizza\resources\views/cart.blade.php ENDPATH**/ ?>