<?php $__env->startSection('content'); ?>
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
    <div class="container px-6 mx-auto pt-[100px]">
        <div class="grid grid-cols-1 gap-6 mt-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            <?php $__currentLoopData = $pizzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pizza): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="w-full max-w-sm mx-auto overflow-hidden rounded-md shadow-md bg-white">
                <div class="flex items-end justify-end w-full bg-cover">

                </div>
                <div class="px-5 py-3">
                    <h3 class="text-gray-700 uppercase">Pizza <?php echo e($pizza->name); ?></h3>
                    <span class="mt-2 text-gray-500"><?php echo e($pizza->price); ?></span>
                    <br>
                    <span class="mt-2 text-gray-500"><?php echo e($pizza->description); ?></span>
                    <form action="<?php echo e(route('Winkelmandje.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($pizza->id); ?>" name="id">
                        <input type="hidden" value="<?php echo e($pizza->name); ?>" name="name">
                        <input type="hidden" value="<?php echo e($pizza->price); ?>" name="price">

                        <label>Klein 20cm</label>
                        <input type="radio" name="groote" value=0.8>
                        <br>
                        <label>Medium 25cm</label>
                        <input type="radio" name="groote" value=1 checked>
                        <br>
                        <label>Groot 30cm</label>
                        <input type="radio" name="groote" value=1.2>
                        <br>
                        <button class="px-4 py-2 text-white bg-blue-800 rounded">Toevoegen</button>
                    </form>
                </div>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.app-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Data\School\Project3\StonksPizza\resources\views/pizza/index.blade.php ENDPATH**/ ?>