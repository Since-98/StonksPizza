<?php

namespace App\Http\Controllers;
use App\Models\Menu;
use Illuminate\Http\Request;
use App\Models\CartItem;

class CartController extends Controller
{
    public function viewCart()
    {


        $cartItems = CartItem::all();
        $totaal = $cartItems->sum('prijs');

        return view('cart.index', ['cartItems' => $cartItems, 'totaal' => $totaal]);


    }
    public function store(Request $request)
    {
        $request->validate([
            'menu_id' => 'required',
            'grootte' => 'required',
            'ingredient' => 'required',
            'quantity' => 'required',
        ]);

        // menu details
        $menu = Menu::find($request->get('menu_id'));


        if (!$menu) {
            return redirect()->route('cart.index')->with('error', 'Menu not found');
        }


        $calculatedPrijs = $menu->prijs * $request->get('grootte') * $request->get('quantity');


        $newCartItem = new CartItem([
            'pizza' => $menu->pizza, // Use the pizza value from the retrieved menu
            'grootte' => $request->get('grootte'),
            'quantity' => $request->get('quantity'),
            'prijs' => $calculatedPrijs,
            'menu_id' => $request->get('menu_id'),
        ]);


        $newCartItem->save();

        
        session()->flash('success', 'Item added to the cart successfully');


        return redirect()->route('cart.index');
    }

        public function destroy($id)
        {
            $cartItem = CartItem::find($id);

            if (!$cartItem) {
                return redirect()->route('cart.index')->with('error', 'Item not found');
            }

            $cartItem->delete();

            return redirect()->route('cart.index')->with('success', 'Item deleted successfully');
        }
}
