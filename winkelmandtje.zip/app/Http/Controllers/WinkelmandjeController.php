<?php

namespace App\Http\Controllers;

use App\Models\Winkelmandje;
use Illuminate\Http\Request;

class WinkelmandjeController extends Controller
{

    public function showCart()
    {
   
    }

}
